CLEANPRO CLEANING WEBSITE
=========================
Files:
- index.html       Home
- about.html       About
- services.html    Services
- gallery.html     Gallery + Reviews
- contact.html     Contact form
- style.css        Main design
- script.js        Mobile menu + demo form

HOW TO TEST:
1. Extract the ZIP.
2. Open index.html in an HTML editor such as Spck Editor or another HTML editor.
3. Preview/run index.html.
4. The site uses online Unsplash images, so internet is needed for the photos.

IMPORTANT:
This is a portfolio/practice template. Replace the sample business name, phone, email,
location, text, images and testimonials with real client-provided information before
delivering paid work.
